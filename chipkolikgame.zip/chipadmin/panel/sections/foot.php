            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>Chipkolik &copy; 2021</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a href="https://phpci.net" class="external">PHPCI</a></p>
                </div>
              </div>
            </div>