<?php  
require_once("../../../app/connect.php");
session_start();

$ip		      = $_SERVER["REMOTE_ADDR"];
$timeDamga    = time();
$time         = date("Y/m/d", $timeDamga);

$backurl	  = $_SERVER['HTTP_REFERER'];

function Security($var){
	$clearSpace		= trim($var);
	$clearTag       = strip_tags($clearSpace);
	$etkisizyap     = htmlspecialchars($clearTag);
	$result   	    = $etkisizyap;
	return $result;
}

if (array_key_exists('newproduct', $_POST)) {

	if (isset($_POST["category"])) {
	$inputcategory = Security($_POST["category"]);
} else
	$inputcategory = "";

	if (isset($_POST["title"])) {
	$inputtitle = Security($_POST["title"]);
} else
	$inputtitle = "";

	if (isset($_POST["qty"])) {
	$inputqty = Security($_POST["qty"]);
} else
	$inputqty = "";

if (isset($_POST["price"])) {
	$inputprice = Security($_POST["price"]);
} else
	$inputprice = "";

if (isset($_POST["stock"])) {
	$inputstock = Security($_POST["stock"]);
} else
	$inputstock = "";



    $currentDirectory = $_SERVER['DOCUMENT_ROOT'];
    $uploadDirectory = "/images/";

    $errors = []; // Store errors here

    $fileExtensionsAllowed = ['jpeg','jpg','png']; // These will be the only file extensions allowed 

    $fileName = $_FILES['the_file']['name'];
    $fileSize = $_FILES['the_file']['size'];
    $fileTmpName  = $_FILES['the_file']['tmp_name'];
    $fileType = $_FILES['the_file']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    $uploadPath = $currentDirectory . $uploadDirectory . basename($fileName); 

    if (isset($_POST['newproduct'])) {

      if (! in_array($fileExtension,$fileExtensionsAllowed)) {
        $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
      }

      if ($fileSize > 4000000) {
        $errors[] = "File exceeds maximum size (4MB)";
      }

      if (empty($errors)) {
        $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

        if ($didUpload) {
        	
        } else {
          echo "An error occurred. Please contact the administrator.";
        }
      } else {
        foreach ($errors as $error) {
          echo $error . "These are the errors" . "\n";
        }
      }

    }

		$productİnsertQuery = $dbConnect->prepare("INSERT INTO product (category_id, title, image, qty, price, stock, statu) values (?,?,?,?,?,?,?)");
		$productİnsertQuery->execute([$inputcategory, $inputtitle, $fileName, $inputqty, $inputprice, $inputstock, 1]);
		$insertControl = $productİnsertQuery->rowCount();

		if ($insertControl > 0) {
			header("Location:/chipadmin/panel/products.php");
			exit();
		} else {
			echo "error newprod reg";
		}
	

}



if (array_key_exists('updateproduct', $_POST)) {

                $productQuery = $dbConnect->prepare("SELECT * FROM product WHERE id = ?");
                $productQuery->execute([$_POST["pid"]]);
                $productNum = $productQuery->rowCount();
                $product = $productQuery->fetch(PDO::FETCH_ASSOC);  

  if (isset($_POST["category"])) {
  $inputcategory = Security($_POST["category"]);
} else
  $inputcategory = "";

  if (isset($_POST["title"])) {
  $inputtitle = Security($_POST["title"]);
} else
  $inputtitle = "";

  if (isset($_POST["qty"])) {
  $inputqty = Security($_POST["qty"]);
} else
  $inputqty = "";

if (isset($_POST["price"])) {
  $inputprice = Security($_POST["price"]);
} else
  $inputprice = "";

if (isset($_POST["stock"])) {
  $inputstock = Security($_POST["stock"]);
} else
  $inputstock = "";



if ($_FILES["the_file"]["name"] != null) {
    
    $currentDirectory = $_SERVER['DOCUMENT_ROOT'];
    $uploadDirectory = "/images/";

    $errors = []; // Store errors here

    $fileExtensionsAllowed = ['jpeg','jpg','png']; // These will be the only file extensions allowed 

    $fileName = $_FILES['the_file']['name'];
    $fileSize = $_FILES['the_file']['size'];
    $fileTmpName  = $_FILES['the_file']['tmp_name'];
    $fileType = $_FILES['the_file']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    $uploadPath = $currentDirectory . $uploadDirectory . basename($fileName); 

    if (isset($_POST['updateproduct'])) {

      if (! in_array($fileExtension,$fileExtensionsAllowed)) {
        $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
      }

      if ($fileSize > 4000000) {
        $errors[] = "File exceeds maximum size (4MB)";
      }

      if (empty($errors)) {
        $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

        if ($didUpload) {
          
        } else {
          echo "An error occurred. Please contact the administrator.";
        }
      } else {
        foreach ($errors as $error) {
          echo $error . "These are the errors" . "\n";
        }
      }

    }
} else {
  $fileName = $product["image"];
}


    $productİnsertQuery = $dbConnect->prepare("UPDATE product SET
      category_id = ?, title = ?, image = ?, qty = ?, price = ?, stock = ?, statu = ?
      WHERE id = ?");
    $productİnsertQuery->execute([$inputcategory, $inputtitle, $fileName, $inputqty, $inputprice, $inputstock, $product["statu"], $_POST["pid"]]);
    $insertControl = $productİnsertQuery->rowCount();

   
      header("Location:/chipadmin/panel/products.php");
      exit();
    
}


if (array_key_exists('productstatuchange', $_GET)) {

    $productQuery = $dbConnect->prepare("SELECT * FROM product WHERE id = ?");
    $productQuery->execute([$_GET["productstatuchange"]]);
    $productNum = $productQuery->rowCount();
    $product = $productQuery->fetch(PDO::FETCH_ASSOC);  

    if ($product["statu"] == 0) {
      $newstatu = 1;
    } else {
      $newstatu = 0;
    }

    if ($productNum == 1) {
      $productİnsertQuery = $dbConnect->prepare("UPDATE product SET
      statu = ?
      WHERE id = ?");
      $productİnsertQuery->execute([$newstatu, $product["id"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 16546683";
    }    

}


if (array_key_exists('productdelete', $_GET)) {

    $productQuery = $dbConnect->prepare("SELECT * FROM product WHERE id = ?");
    $productQuery->execute([$_GET["productdelete"]]);
    $productNum = $productQuery->rowCount();
    $product = $productQuery->fetch(PDO::FETCH_ASSOC);  

    if ($productNum == 1) {
      $productİnsertQuery = $dbConnect->prepare("UPDATE product SET deleted = 1 
        WHERE id = ?");
      $productİnsertQuery->execute([$product["id"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 435465280";
    }    

}



if (array_key_exists('newcategory', $_POST)) {

  if (isset($_POST["title"])) {
  $inputtitle = Security($_POST["title"]);
} else
  $inputtitle = "";

  if (isset($_POST["producttype"])) {
  $inputproducttype = Security($_POST["producttype"]);
} else
  $inputproducttype = "";

if (isset($_POST["description"])) {
  $inputdescription = Security($_POST["description"]);
} else
  $inputdescription = "";

if (isset($_POST["price"])) {
  $inputprice = Security($_POST["price"]);
} else
  $inputprice = "";

if (isset($_POST["birim1"])) {
  $inputbirim1 = Security($_POST["birim1"]);
} else
  $inputbirim1 = "";

if (isset($_POST["birim2"])) {
  $inputbirim2 = Security($_POST["birim2"]);
} else
  $inputbirim2 = "";



    $currentDirectory = $_SERVER['DOCUMENT_ROOT'];
    $uploadDirectory = "/images/";

    $errors = []; // Store errors here

    $fileExtensionsAllowed = ['jpeg','jpg','png']; // These will be the only file extensions allowed 

    $fileName = $_FILES['the_file']['name'];
    $fileSize = $_FILES['the_file']['size'];
    $fileTmpName  = $_FILES['the_file']['tmp_name'];
    $fileType = $_FILES['the_file']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    $uploadPath = $currentDirectory . $uploadDirectory . basename($fileName); 

    if (isset($_POST['newproduct'])) {

      if (! in_array($fileExtension,$fileExtensionsAllowed)) {
        $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
      }

      if ($fileSize > 4000000) {
        $errors[] = "File exceeds maximum size (4MB)";
      }

      if (empty($errors)) {
        $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

        if ($didUpload) {
          
        } else {
          echo "An error occurred. Please contact the administrator.";
        }
      } else {
        foreach ($errors as $error) {
          echo $error . "These are the errors" . "\n";
        }
      }

    }

    $productİnsertQuery = $dbConnect->prepare("INSERT INTO category (title, product_type, description, price, birim1, birim2, image, in_name, in_facemail, in_facepass, in_phone, in_gameid, in_zyngavip, custompacket, statu) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $productİnsertQuery->execute([$inputtitle, $inputproducttype, $inputdescription, $inputprice, $inputbirim1, $inputbirim2, $fileName, $_POST["checkInName"], $_POST["checkInFace"], $_POST["checkInFacePass"], $_POST["checkInPhone"], $_POST["checkInGameId"], $_POST["checkInZyngaVip"], $_POST["custompacket"], 1]);
    $insertControl = $productİnsertQuery->rowCount();

    if ($insertControl > 0) {
      header("Location:/chipadmin/panel/categories.php");
      exit();
    } else {
      echo "error newprod reg";
    }
  

}


if (array_key_exists('updatecategory', $_POST)) {

$categoryQuery = $dbConnect->prepare("SELECT * FROM category WHERE id = ?");
$categoryQuery->execute([$_POST["updatecategory"]]);
$categoryNum = $categoryQuery->rowCount();
$category = $categoryQuery->fetch(PDO::FETCH_ASSOC);

  if (isset($_POST["title"])) {
  $inputtitle = Security($_POST["title"]);
} else
  $inputtitle = "";

  if (isset($_POST["producttype"])) {
  $inputproducttype = Security($_POST["producttype"]);
} else
  $inputproducttype = "";

if (isset($_POST["description"])) {
  $inputdescription = Security($_POST["description"]);
} else
  $inputdescription = "";

if (isset($_POST["price"])) {
  $inputprice = Security($_POST["price"]);
} else
  $inputprice = "";

if (isset($_POST["birim1"])) {
  $inputbirim1 = Security($_POST["birim1"]);
} else
  $inputbirim1 = "";

if (isset($_POST["birim2"])) {
  $inputbirim2 = Security($_POST["birim2"]);
} else
  $inputbirim2 = "";


if (($_FILES["the_file"]["name"] != null)) {
  
    $currentDirectory = $_SERVER['DOCUMENT_ROOT'];
    $uploadDirectory = "/images/";

    $errors = []; // Store errors here

    $fileExtensionsAllowed = ['jpeg','jpg','png']; // These will be the only file extensions allowed 

    $fileName = $_FILES['the_file']['name'];
    $fileSize = $_FILES['the_file']['size'];
    $fileTmpName  = $_FILES['the_file']['tmp_name'];
    $fileType = $_FILES['the_file']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    $uploadPath = $currentDirectory . $uploadDirectory . basename($fileName); 

    if (isset($_POST['updatecategory'])) {

      if (! in_array($fileExtension,$fileExtensionsAllowed)) {
        $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
      }

      if ($fileSize > 4000000) {
        $errors[] = "File exceeds maximum size (4MB)";
      }

      if (empty($errors)) {
        $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

        if ($didUpload) {
          
        } else {
          echo "An error occurred. Please contact the administrator.";
        }
      } else {
        foreach ($errors as $error) {
          echo $error . "These are the errors" . "\n";
        }
      }

    }
  } else {
    $fileName = $category["image"];
  }

    $productİnsertQuery = $dbConnect->prepare("UPDATE category SET 
      title = ?, product_type = ?, description = ?, price = ?, birim1 = ?, birim2 = ?, image = ?, in_name = ?, in_facemail = ?, in_facepass = ?, in_phone = ?, in_gameid = ?, in_zyngavip = ?, custompacket = ?, statu = ? 
      WHERE id = ?");
    $productİnsertQuery->execute([$inputtitle, $inputproducttype, $inputdescription, $inputprice, $inputbirim1, $inputbirim2, $fileName, $_POST["checkInName"], $_POST["checkInFace"], $_POST["checkInFacePass"], $_POST["checkInPhone"], $_POST["checkInGameId"], $_POST["checkInZyngaVip"], $_POST["custompacket"], 1, $category["id"]]);
    $insertControl = $productİnsertQuery->rowCount();

      header("Location:/chipadmin/panel/categories.php");
      exit();
}


if (array_key_exists('categorystatuchange', $_GET)) {

    $categoryQuery = $dbConnect->prepare("SELECT * FROM category WHERE id = ?");
    $categoryQuery->execute([$_GET["categorystatuchange"]]);
    $categoryNum = $categoryQuery->rowCount();
    $category = $categoryQuery->fetch(PDO::FETCH_ASSOC);  

    if ($category["statu"] == 0) {
      $newstatu = 1;
    } else {
      $newstatu = 0;
    }

    if ($categoryNum == 1) {
      $categoryİnsertQuery = $dbConnect->prepare("UPDATE category SET
      statu = ?
      WHERE id = ?");
      $categoryİnsertQuery->execute([$newstatu, $category["id"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 49986102235";
    }    

}


if (array_key_exists('categorydelete', $_GET)) {

    $categoryQuery = $dbConnect->prepare("SELECT * FROM category WHERE id = ?");
    $categoryQuery->execute([$_GET["categorydelete"]]);
    $categoryNum = $categoryQuery->rowCount();
    $category = $categoryQuery->fetch(PDO::FETCH_ASSOC);  

    if ($categoryNum == 1) {
      $categoryİnsertQuery = $dbConnect->prepare("UPDATE category SET deleted = 1 
        WHERE id = ?");
      $categoryİnsertQuery->execute([$category["id"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 435465280";
    }    

}



if (array_key_exists('orderstatuchange', $_GET)) {

    $orderQuery = $dbConnect->prepare("SELECT * FROM orders WHERE id = ?");
    $orderQuery->execute([$_GET["orderstatuchange"]]);
    $orderNum = $orderQuery->rowCount();
    $order = $orderQuery->fetch(PDO::FETCH_ASSOC);  

    if ($orderNum == 1) {
      $orderChangeQuery = $dbConnect->prepare("UPDATE orders SET statu = ? 
        WHERE id = ?");
      $orderChangeQuery->execute([$_GET["statu"], $_GET["orderstatuchange"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 623065485547";
    }    

}


if (array_key_exists('orderdelete', $_GET)) {

    $orderQuery = $dbConnect->prepare("SELECT * FROM orders WHERE id = ?");
    $orderQuery->execute([$_GET["orderdelete"]]);
    $orderNum = $orderQuery->rowCount();
    $order = $orderQuery->fetch(PDO::FETCH_ASSOC);  

    if ($orderNum == 1) {
      $orderChangeQuery = $dbConnect->prepare("UPDATE orders SET deleted = 1 
        WHERE id = ?");
      $orderChangeQuery->execute([$_GET["orderdelete"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 12056284289";
    }    

}


if (array_key_exists('newbank', $_POST)) {

  if (isset($_POST["title"])) {
  $inputtitle = Security($_POST["title"]);
} else
  $inputtitle = "";

  if (isset($_POST["name"])) {
  $inputname = Security($_POST["name"]);
} else
  $inputname = "";

if (isset($_POST["sube"])) {
  $inputsube = Security($_POST["sube"]);
} else
  $inputsube = "";

if (isset($_POST["account_number"])) {
  $inputaccount_number = Security($_POST["account_number"]);
} else
  $inputaccount_number = "";

if (isset($_POST["iban"])) {
  $inputiban = Security($_POST["iban"]);
} else
  $inputiban = "";

if (isset($_POST["price"])) {
  $inputprice = Security($_POST["price"]);
} else
  $inputprice = "";

    $currentDirectory = $_SERVER['DOCUMENT_ROOT'];
    $uploadDirectory = "/images/banks/";

    $errors = []; // Store errors here

    $fileExtensionsAllowed = ['jpeg','jpg','png']; // These will be the only file extensions allowed 

    $fileName = $_FILES['the_file']['name'];
    $fileSize = $_FILES['the_file']['size'];
    $fileTmpName  = $_FILES['the_file']['tmp_name'];
    $fileType = $_FILES['the_file']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    $uploadPath = $currentDirectory . $uploadDirectory . basename($fileName); 

      if (! in_array($fileExtension,$fileExtensionsAllowed)) {
        $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
      }

      if ($fileSize > 4000000) {
        $errors[] = "File exceeds maximum size (4MB)";
      }

      if (empty($errors)) {
        $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

        if ($didUpload) {
          
        } else {
          echo "An error occurred. Please contact the administrator.";
        }
      } else {
        foreach ($errors as $error) {
          echo $error . "These are the errors" . "\n";
        }
      }

  
    $bankİnsertQuery = $dbConnect->prepare("INSERT INTO bank (title, name, sube, account_number, iban, price, image, statu) values (?,?,?,?,?,?,?,?)");
    $bankİnsertQuery->execute([$inputtitle, $inputname, $inputsube, $inputaccount_number, $inputiban, $inputprice, $fileName, 1]);
    $insertControl = $bankİnsertQuery->rowCount();

    if ($insertControl > 0) {
      header("Location:/chipadmin/panel/banks.php");
      exit();
    } else {
      echo "error newbank reg HATA KODU: 876505462322";
    }
  

}


if (array_key_exists('updatebank', $_POST)) {

$bankQuery = $dbConnect->prepare("SELECT * FROM bank WHERE id = ?");
$bankQuery->execute([$_POST["updatebank"]]);
$bankNum = $bankQuery->rowCount();
$bank = $bankQuery->fetch(PDO::FETCH_ASSOC);  

  if (isset($_POST["title"])) {
  $inputtitle = Security($_POST["title"]);
} else
  $inputtitle = "";

  if (isset($_POST["name"])) {
  $inputname = Security($_POST["name"]);
} else
  $inputname = "";

if (isset($_POST["sube"])) {
  $inputsube = Security($_POST["sube"]);
} else
  $inputsube = "";

if (isset($_POST["account_number"])) {
  $inputaccount_number = Security($_POST["account_number"]);
} else
  $inputaccount_number = "";

  if (isset($_POST["iban"])) {
  $inputiban = Security($_POST["iban"]);
} else
  $inputiban = "";

if (isset($_POST["price"])) {
  $inputprice = Security($_POST["price"]);
} else
  $inputprice = "";


if ($_FILES["the_file"]["name"] != null) {
    
    $currentDirectory = $_SERVER['DOCUMENT_ROOT'];
    $uploadDirectory = "/images/banks/";

    $errors = []; // Store errors here

    $fileExtensionsAllowed = ['jpeg','jpg','png']; // These will be the only file extensions allowed 

    $fileName = $_FILES['the_file']['name'];
    $fileSize = $_FILES['the_file']['size'];
    $fileTmpName  = $_FILES['the_file']['tmp_name'];
    $fileType = $_FILES['the_file']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    $uploadPath = $currentDirectory . $uploadDirectory . basename($fileName); 

    if (isset($_POST['updateproduct'])) {

      if (! in_array($fileExtension,$fileExtensionsAllowed)) {
        $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
      }

      if ($fileSize > 4000000) {
        $errors[] = "File exceeds maximum size (4MB)";
      }

      if (empty($errors)) {
        $didUpload = move_uploaded_file($fileTmpName, $uploadPath);

        if ($didUpload) {
          
        } else {
          echo "An error occurred. Please contact the administrator.";
        }
      } else {
        foreach ($errors as $error) {
          echo $error . "These are the errors" . "\n";
        }
      }

    }
} else {
  $fileName = $bank["image"];
}


    $bankİnsertQuery = $dbConnect->prepare("UPDATE bank SET
      title = ?, name = ?, sube = ?, account_number = ?, iban = ?, price = ?, image = ?, statu = ?
      WHERE id = ?");
    $bankİnsertQuery->execute([$inputtitle, $inputname, $inputsube, $inputaccount_number, $inputiban, $inputprice, $fileName, 1, $bank["id"]]);
    $insertControl = $bankİnsertQuery->rowCount();

   
      header("Location:/chipadmin/panel/banks.php");
      exit();
    
}


if (array_key_exists('bankstatuchange', $_GET)) {

    $bankQuery = $dbConnect->prepare("SELECT * FROM bank WHERE id = ?");
    $bankQuery->execute([$_GET["bankstatuchange"]]);
    $bankNum = $bankQuery->rowCount();
    $bank = $bankQuery->fetch(PDO::FETCH_ASSOC);  

    if ($bankNum == 1) {
      $bankChangeQuery = $dbConnect->prepare("UPDATE bank SET statu = ? 
        WHERE id = ?");
      $bankChangeQuery->execute([$_GET["statu"], $_GET["bankstatuchange"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 461531368005";
    }    

}


if (array_key_exists('bankdelete', $_GET)) {

    $bankQuery = $dbConnect->prepare("SELECT * FROM bank WHERE id = ?");
    $bankQuery->execute([$_GET["bankdelete"]]);
    $bankNum = $bankQuery->rowCount();
    $bank = $bankQuery->fetch(PDO::FETCH_ASSOC);  

    if ($bankNum == 1) {
      $bankChangeQuery = $dbConnect->prepare("UPDATE bank SET deleted = 1 
        WHERE id = ?");
      $bankChangeQuery->execute([$_GET["bankdelete"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 74032213885";
    }    

}



if (array_key_exists('newblog', $_POST)) {

  if (isset($_POST["title"])) {
  $inputtitle = Security($_POST["title"]);
} else
  $inputtitle = "";

  if (isset($_POST["text"])) {
  $inputtext = Security($_POST["text"]);
} else
  $inputtext = "";

if (isset($_POST["topic"])) {
  $inputtopic = Security($_POST["topic"]);
} else
  $inputtopic = "";

    $blogİnsertQuery = $dbConnect->prepare("INSERT INTO blogs (title, text, topic, statu, created_at) values (?,?,?,?,?)");
    $blogİnsertQuery->execute([$inputtitle, $inputtext, $inputtopic, 1, $time]);
    $insertControl = $blogİnsertQuery->rowCount();

    if ($insertControl > 0) {
      header("Location:/chipadmin/panel/blogs.php");
      exit();
    } else {
      echo "error newbank reg HATA KODU: 5641279893001";
    }
  

}


if (array_key_exists('updateblog', $_POST)) {

$blogQuery = $dbConnect->prepare("SELECT * FROM blogs WHERE id = ?");
$blogQuery->execute([$_POST["updateblog"]]);
$blogNum = $blogQuery->rowCount();
$blog = $blogQuery->fetch(PDO::FETCH_ASSOC);  

  if (isset($_POST["title"])) {
  $inputtitle = Security($_POST["title"]);
} else
  $inputtitle = "";

  if (isset($_POST["text"])) {
  $inputtext = Security($_POST["text"]);
} else
  $inputtext = "";

if (isset($_POST["topic"])) {
  $inputtopic = Security($_POST["topic"]);
} else
  $inputtopic = "";

    $blogİnsertQuery = $dbConnect->prepare("UPDATE blogs SET
      title = ?, text = ?, topic = ?, statu = ?, created_at = ?
      WHERE id = ?");
    $blogİnsertQuery->execute([$inputtitle, $inputtext, $inputtopic, 1, $time, $blog["id"]]);
    $insertControl = $blogİnsertQuery->rowCount();

   
      header("Location:/chipadmin/panel/blogs.php");
      exit();
    
}


if (array_key_exists('blogstatuchange', $_GET)) {

    $blogQuery = $dbConnect->prepare("SELECT * FROM blogs WHERE id = ?");
    $blogQuery->execute([$_GET["blogstatuchange"]]);
    $blogNum = $blogQuery->rowCount();
    $blog = $blogQuery->fetch(PDO::FETCH_ASSOC);  

    if ($blogNum == 1) {
      $blogChangeQuery = $dbConnect->prepare("UPDATE blogs SET statu = ? 
        WHERE id = ?");
      $blogChangeQuery->execute([$_GET["statu"], $_GET["blogstatuchange"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 15795651205";
    }    

}


if (array_key_exists('blogdelete', $_GET)) {

    $blogQuery = $dbConnect->prepare("SELECT * FROM blogs WHERE id = ?");
    $blogQuery->execute([$_GET["blogdelete"]]);
    $blogNum = $blogQuery->rowCount();
    $blog = $blogQuery->fetch(PDO::FETCH_ASSOC);  

    if ($blogNum == 1) {
      $blogChangeQuery = $dbConnect->prepare("UPDATE blogs SET deleted = 1 
        WHERE id = ?");
      $blogChangeQuery->execute([$_GET["blogdelete"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 11515795023";
    }    

}



if (array_key_exists('updateUser', $_POST)) {

$userQuery = $dbConnect->prepare("SELECT * FROM users WHERE id = ?");
$userQuery->execute([$_POST["updateUser"]]);
$userNum = $userQuery->rowCount();
$user = $userQuery->fetch(PDO::FETCH_ASSOC);  

  if (isset($_POST["name"])) {
  $inputname = Security($_POST["name"]);
} else
  $inputname = "";

  if (isset($_POST["phone"])) {
  $inputphone = Security($_POST["phone"]);
} else
  $inputphone = "";

if ($_POST["password"] != null) {
  $inputpassword = Security($_POST["password"]);
  $md5pass       = md5($inputpassword);
} else
  $md5pass = $user["password"];

    $userİnsertQuery = $dbConnect->prepare("UPDATE users SET
      name = ?, password = ?, phone = ?
      WHERE id = ?");
    $userİnsertQuery->execute([$inputname, $md5pass, $inputphone, $user["id"]]);
    $insertControl = $userİnsertQuery->rowCount();

      header("Location:/chipadmin/panel/users.php");
      exit();
    
}



if (array_key_exists('userstatuchange', $_GET)) {

    $userQuery = $dbConnect->prepare("SELECT * FROM users WHERE id = ?");
    $userQuery->execute([$_GET["userstatuchange"]]);
    $userNum = $userQuery->rowCount();
    $user = $userQuery->fetch(PDO::FETCH_ASSOC);  

    if ($userNum == 1) {
      $userChangeQuery = $dbConnect->prepare("UPDATE users SET statu = ? 
        WHERE id = ?");
      $userChangeQuery->execute([$_GET["statu"], $_GET["userstatuchange"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 15795651205";
    }    

}



if (array_key_exists('userdelete', $_GET)) {

    $userQuery = $dbConnect->prepare("SELECT * FROM users WHERE id = ?");
    $userQuery->execute([$_GET["userdelete"]]);
    $userNum = $userQuery->rowCount();
    $user = $userQuery->fetch(PDO::FETCH_ASSOC);  

    if ($userNum == 1) {
      $userChangeQuery = $dbConnect->prepare("UPDATE users SET deleted = 1 
        WHERE id = ?");
      $userChangeQuery->execute([$_GET["userdelete"]]); 
      header("Location:" . $backurl);
    } else {
      echo "HATA KODU: 94051238551";
    }    

}




?>