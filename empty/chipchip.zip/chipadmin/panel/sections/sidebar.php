          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4">Chipkolik</h1>
              <p>Admin</p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li class="active"><a href="/chipadmin/panel"> <i class="icon-home"></i>Home </a></li>

            <li><a href="#productsDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Ürünler </a>
              <ul id="productsDropdown" class="collapse list-unstyled ">
                <li><a href="/chipadmin/panel/addproduct.php">Yeni Ürün Ekle</a></li>
                <li><a href="/chipadmin/panel/products.php">Tüm Ürünler</a></li>
              </ul>
            </li>
            <li><a href="#categoriesDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Kategoriler </a>
              <ul id="categoriesDropdown" class="collapse list-unstyled ">
                <li><a href="/chipadmin/panel/addcategory.php">Yeni Kategori Ekle</a></li>
                <li><a href="/chipadmin/panel/categories.php">Tüm Kategoriler</a></li>
              </ul>
            </li>     
            <li><a href="#ordersDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Siparişler </a>
              <ul id="ordersDropdown" class="collapse list-unstyled ">
                <li><a href="/chipadmin/panel/orders1.php">Ödeme Bekleyen</a></li>
                <li><a href="/chipadmin/panel/orders2.php">Teslimat Bekleyen</a></li>                 
                <li><a href="/chipadmin/panel/orders3.php">İptal Siparişler</a></li> 
                <li><a href="/chipadmin/panel/orders4.php">Tamamlanan Siparişler</a></li>                              
                <li><a href="/chipadmin/panel/orders.php">Tüm Siparişler</a></li>
              </ul>
            </li>             
            <li><a href="/chipadmin/panel/banks.php"> <i class="icon-grid"></i>Banka Bilgileri </a></li>
            <li><a href="/chipadmin/panel/blogs.php"> <i class="fa fa-bar-chart"></i>Haberler </a></li>
            <!-- <li><a href="forms.html"> <i class="icon-padnote"></i>Sayfalar </a></li>  -->                  
            <li><a href="/chipadmin/panel/users.php"> <i class="icon-interface-windows"></i>Kullanıcılar </a></li>
          </ul><span class="heading">Extras</span>
          <ul class="list-unstyled">
            <li> <a href="#"> <i class="icon-flask"></i>Ayarlar </a></li>
            <li> <a href="#"> <i class="icon-screen"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-mail"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-picture"></i>Demo </a></li>
          </ul>