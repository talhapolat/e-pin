<div class="p-b-10">
				<h3 class="ltext-103 cl5">
					<i class="fas fa-question-circle"></i> SORULAR
				</h3>
			</div>

					<ul class="list-group p-t-10">
  <li class="list-group-item ssslist"><a class="cl2 hov-cl1 trans-04" href="">NASIL ÜYE OLURUM ?</a></li>
  <li class="list-group-item ssslist"><a class="cl2 hov-cl1 trans-04" href="">NASIL ALIŞVERİŞ YAPARIM ?</a></li>
  <li class="list-group-item ssslist"><a class="cl2 hov-cl1 trans-04" href="">ÇALIŞMA VE TESLİMAT SAATLERİNİZ ?</a></li>
  <li class="list-group-item ssslist"><a class="cl2 hov-cl1 trans-04" href="">BANKA NE KADAR KESİNTİ YAPAR ?</a></li>
  <li class="list-group-item ssslist"><a class="cl2 hov-cl1 trans-04" href="">ÖDEME YÖNTEMLERİ NELER ?</a></li>
  <li class="list-group-item ssslist"><a class="cl2 hov-cl1 trans-04" href="">SİPARİŞİM HANGİ AŞAMADA ?</a></li>
</ul>