<div class="duyuruheader" style="width: 100%; background-color: #183153">
		<div class="container py-3" style="color: white; font-family: fa5-proxima-nova,'Helvetica Neue',Helvetica,Arial,sans-serif;">
			<h5 class="py-2">Türkiye'nin Güvenilir Oyun Marketi</h5>
			<p style="color: #c3c6d1">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
	</div>

	<div class="duyuruheadermobile" style="width: 100%; background-color: #183153">
		<div class="container py-3" style="color: white; font-family: fa5-proxima-nova,'Helvetica Neue',Helvetica,Arial,sans-serif;">
			<h5 class="py-2">Türkiye'nin Güvenilir Oyun Marketi</h5>
		</div>
	</div>